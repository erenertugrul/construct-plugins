"use strict";

{
	const PLUGIN_CLASS = SDK.Plugins.Rex_tmx_XML_parser;

	PLUGIN_CLASS.Type = class Rex_tmx_XML_parserType extends SDK.ITypeBase
	{
		constructor(sdkPlugin, iObjectType)
		{
			super(sdkPlugin, iObjectType);
		}
	};
}
