"use strict";

{
	C3.Plugins.Rex_tmx_XML_parser.Exps =
	{
		Double(number)
		{
			return number * 2;
		}
	};
}