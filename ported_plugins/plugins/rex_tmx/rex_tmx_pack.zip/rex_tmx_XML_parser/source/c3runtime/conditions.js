"use strict";

{
	C3.Plugins.Rex_tmx_XML_parser.Cnds =
	{
		IsLargeNumber(number)
		{
			return number > 100;
		}
	};
}