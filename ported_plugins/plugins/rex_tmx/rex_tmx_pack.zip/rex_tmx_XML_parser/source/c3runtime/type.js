"use strict";

{
	C3.Plugins.Rex_tmx_XML_parser.Type = class Rex_tmx_XML_parserType extends C3.SDKTypeBase
	{
		constructor(objectClass)
		{
			super(objectClass);
		}
		
		Release()
		{
			super.Release();
		}
		
		OnCreate()
		{	
		}
	};
}