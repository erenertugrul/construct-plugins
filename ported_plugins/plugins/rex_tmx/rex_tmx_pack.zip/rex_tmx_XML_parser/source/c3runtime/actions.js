"use strict";

{
	C3.Plugins.Rex_tmx_XML_parser.Acts =
	{
		Alert()
		{
			alert("Test property = " + this._testProperty);
		}
	};
}