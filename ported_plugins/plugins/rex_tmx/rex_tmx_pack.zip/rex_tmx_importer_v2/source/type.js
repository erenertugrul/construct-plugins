"use strict";

{
	const PLUGIN_CLASS = SDK.Plugins.Rex_tmx_importer_v2;

	PLUGIN_CLASS.Type = class Rex_tmx_importer_v2Type extends SDK.ITypeBase
	{
		constructor(sdkPlugin, iObjectType)
		{
			super(sdkPlugin, iObjectType);
		}
	};
}
