"use strict";

{
	C3.Plugins.Rex_tmx_JSON_parser.Exps =
	{

	};
}