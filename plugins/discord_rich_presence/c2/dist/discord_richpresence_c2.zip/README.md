discord richpresence

step 1

get client id
https://discordapp.com/developers/applications/

step 2

export nwjs

step 3

extract node_modules.zip file.
copy package.nw (if you using mac copy to app.nw)



<table>
<thead>
<tr>
<th>patreon</th>
<th>buymeacoffee</th>
</tr>
</thead>
<tbody>
<td style="text-align:center"><a href="https://www.patreon.com/oyun" target="_blank"><img src="https://i.imgur.com/T4hQeAV.png"></img></a></td>
<td style="text-align:center"><a href="https://www.buymeacoffee.com/eren" target="_blank"><img src="https://i.imgur.com/pjkMdHU.png"></img></a></td>
</tr>
</tbody>
</table>
